package com.example.personalbudgetingapp

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.personalbudgetingapp.data.AppDao
import com.example.personalbudgetingapp.data.AppDatabase
import com.example.personalbudgetingapp.data.Category
import com.example.personalbudgetingapp.data.Expense
import com.example.personalbudgetingapp.data.Goal
import com.example.personalbudgetingapp.ui.theme.PersonalBudgetingAppTheme
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.ktx.auth
import com.google.firebase.ktx.Firebase
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

class DashboardActivity : ComponentActivity() {

    private lateinit var auth: FirebaseAuth

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Initialize Firebase Auth
        auth = Firebase.auth

        // Initialize the database and DAO
        val database = AppDatabase.getDatabase(this)
        val dao = database.appDao()

        setContent {
            PersonalBudgetingAppTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    DashboardScreen(
                        dao = dao,
                        onLogout = {
                            auth.signOut()
                            startActivity(Intent(this, AuthActivity::class.java))
                            finish()
                        }
                    )
                }
            }
        }
    }
}

@Composable
fun DashboardScreen(
    dao: AppDao,
    onLogout: () -> Unit,
    viewModel: DashboardViewModel = viewModel(factory = DashboardViewModelFactory(dao))
) {
    var showAddExpenseDialog by remember { mutableStateOf(false) }
    var showAddCategoryDialog by remember { mutableStateOf(false) }
    var showSetGoalDialog by remember { mutableStateOf(false) }

    // Observe the latest goal
    val latestGoal by viewModel.latestGoal.collectAsState(initial = null)
    // Observe all expenses
    val expenses by viewModel.expenses.collectAsState(initial = emptyList())
    // Observe all categories
    val categories by viewModel.categories.collectAsState(initial = emptyList())

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        // Header with Logout Button
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "Dashboard",
                fontSize = 24.sp
            )
            Button(
                onClick = onLogout,
                colors = ButtonDefaults.buttonColors(
                    containerColor = MaterialTheme.colorScheme.error
                )
            ) {
                Text("Logout")
            }
        }

        // Monthly Goal Section
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 16.dp)
                .clickable { showSetGoalDialog = true }
        ) {
            Column(
                modifier = Modifier.padding(16.dp)
            ) {
                Text(
                    text = "Monthly Goal",
                    fontSize = 18.sp,
                    modifier = Modifier.padding(bottom = 8.dp)
                )
                Text(
                    text = latestGoal?.let { "Goal: $${String.format(Locale.US, "%.2f", it.monthlyGoal)}" } ?: "No goal set",
                    fontSize = 16.sp
                )
            }
        }

        // Total Expenses
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 16.dp)
        ) {
            Column(
                modifier = Modifier.padding(16.dp)
            ) {
                Text(
                    text = "Total Expenses This Month",
                    fontSize = 18.sp,
                    modifier = Modifier.padding(bottom = 8.dp)
                )
                val totalExpenses = expenses.sumOf { it.amount }
                Text(
                    text = "$${String.format(Locale.US, "%.2f", totalExpenses)}",
                    fontSize = 16.sp
                )
            }
        }

        // Add Expense and Category Buttons
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 16.dp),
            horizontalArrangement = Arrangement.SpaceEvenly
        ) {
            Button(onClick = { showAddExpenseDialog = true }) {
                Text("Add Expense")
            }
            Button(onClick = { showAddCategoryDialog = true }) {
                Text("Add Category")
            }
        }

        // Expenses List
        Text(
            text = "Recent Expenses",
            fontSize = 18.sp,
            modifier = Modifier.padding(bottom = 8.dp)
        )
        LazyColumn {
            items(expenses) { expense ->
                ExpenseItem(expense)
            }
        }
    }

    // Dialogs
    if (showAddExpenseDialog) {
        AddExpenseDialog(
            categories = categories,
            onDismiss = { showAddExpenseDialog = false },
            onAddExpense = { amount, description, category ->
                viewModel.addExpense(amount, description, category)
                showAddExpenseDialog = false
            }
        )
    }

    if (showAddCategoryDialog) {
        AddCategoryDialog(
            onDismiss = { showAddCategoryDialog = false },
            onAddCategory = { categoryName ->
                viewModel.addCategory(categoryName)
                showAddCategoryDialog = false
            }
        )
    }

    if (showSetGoalDialog) {
        SetGoalDialog(
            onDismiss = { showSetGoalDialog = false },
            onSetGoal = { goalAmount ->
                viewModel.setGoal(goalAmount)
                showSetGoalDialog = false
            }
        )
    }
}

@Composable
fun ExpenseItem(expense: Expense) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp)
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(text = expense.description, fontSize = 16.sp)
                Text(
                    text = "Category: ${expense.category}",
                    fontSize = 14.sp,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
                )
                Text(
                    text = SimpleDateFormat("dd/MM/yyyy", Locale.US).format(Date(expense.date)),
                    fontSize = 14.sp,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
                )
            }
            Text(
                text = "$${String.format(Locale.US, "%.2f", expense.amount)}",
                fontSize = 16.sp,
                color = MaterialTheme.colorScheme.primary
            )
        }
    }
}

@Composable
fun AddExpenseDialog(
    categories: List<Category>,
    onDismiss: () -> Unit,
    onAddExpense: (Double, String, String) -> Unit
) {
    var amount by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }
    var selectedCategory by remember { mutableStateOf(categories.firstOrNull()?.name ?: "") }
    var expanded by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Add Expense") },
        text = {
            Column {
                OutlinedTextField(
                    value = amount,
                    onValueChange = { amount = it },
                    label = { Text("Amount") },
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(modifier = Modifier.height(8.dp))
                OutlinedTextField(
                    value = description,
                    onValueChange = { description = it },
                    label = { Text("Description") },
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(modifier = Modifier.height(8.dp))
                if (categories.isNotEmpty()) {
                    Box {
                        OutlinedTextField(
                            value = selectedCategory,
                            onValueChange = {},
                            label = { Text("Category") },
                            modifier = Modifier.fillMaxWidth(),
                            readOnly = true,
                            trailingIcon = {
                                IconButton(onClick = { expanded = true }) {
                                    Icon(
                                        imageVector = Icons.Default.ArrowDropDown,
                                        contentDescription = "Dropdown"
                                    )
                                }
                            }
                        )
                        DropdownMenu(
                            expanded = expanded,
                            onDismissRequest = { expanded = false },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            categories.forEach { category ->
                                DropdownMenuItem(
                                    text = { Text(category.name) },
                                    onClick = {
                                        selectedCategory = category.name
                                        expanded = false
                                    }
                                )
                            }
                        }
                    }
                } else {
                    Text("No categories available. Add a category first.")
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val amountValue = amount.toDoubleOrNull()
                    if (amountValue != null && description.isNotEmpty() && selectedCategory.isNotEmpty()) {
                        onAddExpense(amountValue, description, selectedCategory)
                    }
                },
                enabled = amount.toDoubleOrNull() != null && description.isNotEmpty() && selectedCategory.isNotEmpty()
            ) {
                Text("Add")
            }
        },
        dismissButton = {
            Button(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}

@Composable
fun AddCategoryDialog(
    onDismiss: () -> Unit,
    onAddCategory: (String) -> Unit
) {
    var categoryName by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Add Category") },
        text = {
            OutlinedTextField(
                value = categoryName,
                onValueChange = { categoryName = it },
                label = { Text("Category Name") },
                modifier = Modifier.fillMaxWidth()
            )
        },
        confirmButton = {
            Button(
                onClick = {
                    if (categoryName.isNotEmpty()) {
                        onAddCategory(categoryName)
                    }
                },
                enabled = categoryName.isNotEmpty()
            ) {
                Text("Add")
            }
        },
        dismissButton = {
            Button(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}

@Composable
fun SetGoalDialog(
    onDismiss: () -> Unit,
    onSetGoal: (Double) -> Unit
) {
    var goalAmount by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Set Monthly Goal") },
        text = {
            OutlinedTextField(
                value = goalAmount,
                onValueChange = { goalAmount = it },
                label = { Text("Goal Amount") },
                modifier = Modifier.fillMaxWidth()
            )
        },
        confirmButton = {
            Button(
                onClick = {
                    val amount = goalAmount.toDoubleOrNull()
                    if (amount != null) {
                        onSetGoal(amount)
                    }
                },
                enabled = goalAmount.toDoubleOrNull() != null
            ) {
                Text("Set")
            }
        },
        dismissButton = {
            Button(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}

class DashboardViewModel(private val dao: AppDao) : ViewModel() {
    val latestGoal: StateFlow<Goal?> = dao.getLatestGoalAsFlow()
        .map { it.firstOrNull() }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val expenses: StateFlow<List<Expense>> = dao.getExpensesByDateRange(getStartOfMonth(), getEndOfMonth())
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val categories: StateFlow<List<Category>> = dao.getAllCategories()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun addExpense(amount: Double, description: String, category: String) {
        val currentTime = System.currentTimeMillis()
        val expense = Expense(
            amount = amount,
            date = currentTime,
            startTime = currentTime,
            endTime = currentTime,
            description = description,
            category = category
        )
        viewModelScope.launch {
            dao.insertExpense(expense) // Ignore the returned Long
        }
    }

    fun addCategory(name: String) {
        val category = Category(name = name)
        viewModelScope.launch {
            dao.insertCategory(category) // Ignore the returned Long
        }
    }

    fun setGoal(amount: Double) {
        val goal = Goal(monthlyGoal = amount)
        viewModelScope.launch {
            dao.insertGoal(goal) // Ignore the returned Long
        }
    }

    private fun getStartOfMonth(): Long {
        val calendar = Calendar.getInstance()
        calendar.set(Calendar.DAY_OF_MONTH, 1)
        calendar.set(Calendar.HOUR_OF_DAY, 0)
        calendar.set(Calendar.MINUTE, 0)
        calendar.set(Calendar.SECOND, 0)
        calendar.set(Calendar.MILLISECOND, 0)
        return calendar.timeInMillis
    }

    private fun getEndOfMonth(): Long {
        val calendar = Calendar.getInstance()
        calendar.set(Calendar.DAY_OF_MONTH, calendar.getActualMaximum(Calendar.DAY_OF_MONTH))
        calendar.set(Calendar.HOUR_OF_DAY, 23)
        calendar.set(Calendar.MINUTE, 59)
        calendar.set(Calendar.SECOND, 59)
        calendar.set(Calendar.MILLISECOND, 999)
        return calendar.timeInMillis
    }
}

class DashboardViewModelFactory(private val dao: AppDao) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(DashboardViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return DashboardViewModel(dao) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}