package com.example.personalbudgetingapp.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "expenses")
data class Expense(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val amount: Double,
    val date: Long, // Store as timestamp
    val startTime: Long,
    val endTime: Long,
    val description: String,
    val category: String,
    val photoUri: String? = null // Optional photo URI
)