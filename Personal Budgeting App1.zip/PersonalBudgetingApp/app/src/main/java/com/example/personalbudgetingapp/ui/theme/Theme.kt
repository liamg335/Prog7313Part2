package com.example.personalbudgetingapp.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

// Define the new colors from the provided palette
private val BudgetGreen = Color(0xFFA8BB80) // #A8BB80
private val BudgetTeal = Color(0xFF47C7D0) // #47C7D0
private val BudgetGrayBlue = Color(0xFFB0C4CA) // #B0C4CA
private val BudgetLightGray = Color(0xFFE0E7E7) // #E0E7E7
private val BudgetAlmostWhite = Color(0xFFF4F9F9) // #F4F9F9

private val DarkColorScheme = darkColorScheme(
    primary = BudgetTeal,
    secondary = BudgetGreen,
    tertiary = BudgetGrayBlue,
    background = Color.Black,
    surface = BudgetGrayBlue,
    onPrimary = Color.Black,
    onSecondary = Color.Black,
    onTertiary = Color.Black,
    onBackground = BudgetAlmostWhite,
    onSurface = BudgetAlmostWhite,
    error = BudgetTeal, // Define error color for dark theme
    onError = Color.Black // Text/icons on error
)

private val LightColorScheme = lightColorScheme(
    primary = BudgetTeal,
    secondary = BudgetGreen,
    tertiary = BudgetGrayBlue,
    background = BudgetAlmostWhite,
    surface = BudgetLightGray,
    onPrimary = Color.Black,
    onSecondary = Color.Black,
    onTertiary = Color.Black,
    onBackground = Color.Black,
    onSurface = Color.Black,
    error = BudgetTeal, // Define error color for light theme
    onError = Color.Black // Text/icons on error
)

@Composable
fun PersonalBudgetingAppTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit
) {
    val colorScheme = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            val context = LocalContext.current
            if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        }
        darkTheme -> DarkColorScheme
        else -> LightColorScheme
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}