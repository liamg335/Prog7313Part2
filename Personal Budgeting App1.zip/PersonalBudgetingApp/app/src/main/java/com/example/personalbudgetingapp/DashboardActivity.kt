package com.example.personalbudgetingapp

import android.app.DatePickerDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.util.Log
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import coil.compose.rememberAsyncImagePainter
import com.example.personalbudgetingapp.data.AppDao
import com.example.personalbudgetingapp.data.Category
import com.example.personalbudgetingapp.data.Expense
import com.example.personalbudgetingapp.data.Goal
import com.example.personalbudgetingapp.ui.theme.PersonalBudgetingAppTheme
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.ktx.auth
import com.google.firebase.ktx.Firebase
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

class DashboardActivity : ComponentActivity() {

    private lateinit var auth: FirebaseAuth
    private val requestPhotoPermissionLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) { isGranted: Boolean ->
        if (isGranted) {
            photoPickerCallback?.invoke()
        } else {
            Toast.makeText(this, "Permission denied to access photos", Toast.LENGTH_LONG).show()
        }
    }
    private val requestCameraPermissionLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) { isGranted: Boolean ->
        if (isGranted) {
            cameraCallback?.invoke()
        } else {
            Toast.makeText(this, "Permission denied to access camera", Toast.LENGTH_LONG).show()
        }
    }
    private var photoPickerCallback: (() -> Unit)? = null
    private var cameraCallback: (() -> Unit)? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Initialize Firebase Auth
        auth = Firebase.auth

        // Get the logged-in user's ID
        val userId = auth.currentUser?.uid ?: run {
            // If no user is logged in, redirect to AuthActivity
            startActivity(Intent(this, AuthActivity::class.java))
            finish()
            return
        }

        // Log the user ID for debugging
        Log.d("DashboardActivity", "User ID on create: $userId")

        // Initialize the database and DAO
        val database = AppDatabase.getDatabase(this)
        val dao = database.appDao()

        setContent {
            PersonalBudgetingAppTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    DashboardScreen(
                        dao = dao,
                        userId = userId,
                        onLogout = {
                            auth.signOut()
                            startActivity(Intent(this, AuthActivity::class.java))
                            finish()
                        },
                        requestPhotoPermission = { callback ->
                            photoPickerCallback = callback
                            requestPhotoPermission()
                        },
                        requestCameraPermission = { callback ->
                            cameraCallback = callback
                            requestCameraPermission()
                        }
                    )
                }
            }
        }
    }

    override fun onStart() {
        super.onStart()
        auth.addAuthStateListener { firebaseAuth ->
            val user = firebaseAuth.currentUser
            if (user == null) {
                Log.d("DashboardActivity", "Auth state changed: User is null, redirecting to AuthActivity")
                startActivity(Intent(this, AuthActivity::class.java))
                finish()
            } else {
                Log.d("DashboardActivity", "Auth state changed: User ID is ${user.uid}")
            }
        }
    }

    private fun requestPhotoPermission() {
        when {
            ContextCompat.checkSelfPermission(this, android.Manifest.permission.READ_MEDIA_IMAGES) == PackageManager.PERMISSION_GRANTED -> {
                photoPickerCallback?.invoke()
            }
            else -> {
                requestPhotoPermissionLauncher.launch(android.Manifest.permission.READ_MEDIA_IMAGES)
            }
        }
    }

    private fun requestCameraPermission() {
        when {
            ContextCompat.checkSelfPermission(this, android.Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED -> {
                cameraCallback?.invoke()
            }
            else -> {
                requestCameraPermissionLauncher.launch(android.Manifest.permission.CAMERA)
            }
        }
    }
}

@Composable
fun DashboardScreen(
    dao: AppDao,
    userId: String,
    onLogout: () -> Unit,
    requestPhotoPermission: ((() -> Unit) -> Unit),
    requestCameraPermission: ((() -> Unit) -> Unit),
    viewModel: DashboardViewModel = viewModel(factory = DashboardViewModelFactory(dao, userId))
) {
    var showAddExpenseDialog by rememberSaveable { mutableStateOf(false) }
    var showAddCategoryDialog by rememberSaveable { mutableStateOf(false) }
    var showSetGoalDialog by rememberSaveable { mutableStateOf(false) }
    var showPhotoDialog by rememberSaveable { mutableStateOf(false) }
    var selectedPhotoPath by rememberSaveable { mutableStateOf<String?>(null) }

    // Observe the latest goal
    val latestGoal by viewModel.latestGoal.collectAsState(initial = null)
    // Observe all expenses
    val expenses by viewModel.expenses.collectAsState(initial = emptyList())
    // Observe all categories
    val categories by viewModel.categories.collectAsState(initial = emptyList())

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        // Header with Logout Button
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "Dashboard",
                fontSize = 24.sp
            )
            Button(
                onClick = onLogout,
                colors = ButtonDefaults.buttonColors(
                    containerColor = MaterialTheme.colorScheme.error
                )
            ) {
                Text("Logout")
            }
        }

        // Monthly Goal Section
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 16.dp)
                .clickable { showSetGoalDialog = true }
        ) {
            Column(
                modifier = Modifier.padding(16.dp)
            ) {
                Text(
                    text = "Monthly Goal",
                    fontSize = 18.sp,
                    modifier = Modifier.padding(bottom = 8.dp)
                )
                Text(
                    text = latestGoal?.let { "Goal: R${String.format(Locale.US, "%.2f", it.monthlyGoal)}" } ?: "No goal set",
                    fontSize = 16.sp
                )
            }
        }

        // Total Expenses
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 16.dp)
        ) {
            Column(
                modifier = Modifier.padding(16.dp)
            ) {
                Text(
                    text = "Total Expenses This Month",
                    fontSize = 18.sp,
                    modifier = Modifier.padding(bottom = 8.dp)
                )
                val totalExpenses = expenses.sumOf { it.amount }
                Text(
                    text = "R${String.format(Locale.US, "%.2f", totalExpenses)}",
                    fontSize = 16.sp
                )
            }
        }

        // Add Expense and Category Buttons
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 16.dp),
            horizontalArrangement = Arrangement.SpaceEvenly
        ) {
            Button(onClick = { showAddExpenseDialog = true }) {
                Text("Add Expense")
            }
            Button(onClick = { showAddCategoryDialog = true }) {
                Text("Add Category")
            }
        }

        // Expenses List
        Text(
            text = "Recent Expenses",
            fontSize = 18.sp,
            modifier = Modifier.padding(bottom = 8.dp)
        )
        LazyColumn {
            items(expenses) { expense ->
                ExpenseItem(
                    expense = expense,
                    onPhotoClick = { photoPath ->
                        selectedPhotoPath = photoPath
                        showPhotoDialog = true
                    }
                )
            }
        }
    }

    // Dialogs
    if (showAddExpenseDialog) {
        AddExpenseDialog(
            categories = categories,
            onDismiss = { showAddExpenseDialog = false },
            onAddExpense = { amount, description, category, selectedDate, photoPath ->
                viewModel.addExpense(amount, description, category, selectedDate, photoPath)
                showAddExpenseDialog = false
            },
            requestPhotoPermission = requestPhotoPermission,
            requestCameraPermission = requestCameraPermission
        )
    }

    if (showAddCategoryDialog) {
        AddCategoryDialog(
            onDismiss = { showAddCategoryDialog = false },
            onAddCategory = { categoryName ->
                viewModel.addCategory(categoryName)
                showAddCategoryDialog = false
            }
        )
    }

    if (showSetGoalDialog) {
        SetGoalDialog(
            onDismiss = { showSetGoalDialog = false },
            onSetGoal = { goalAmount ->
                viewModel.setGoal(goalAmount)
                showSetGoalDialog = false
            }
        )
    }

    if (showPhotoDialog && selectedPhotoPath != null) {
        PhotoViewerDialog(
            photoPath = selectedPhotoPath!!,
            onDismiss = { showPhotoDialog = false }
        )
    }
}

@Composable
fun ExpenseItem(
    expense: Expense,
    onPhotoClick: (String) -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp)
            .clickable {
                expense.photoPath?.let { path ->
                    onPhotoClick(path)
                }
            }
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(text = expense.description, fontSize = 16.sp)
                Text(
                    text = "Category: ${expense.category}",
                    fontSize = 14.sp,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
                )
                Text(
                    text = SimpleDateFormat("dd/MM/yyyy", Locale.US).format(Date(expense.date)),
                    fontSize = 14.sp,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
                )
                expense.photoPath?.let { path ->
                    Text(
                        text = "Photo attached",
                        fontSize = 14.sp,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
                    )
                }
            }
            Text(
                text = "R${String.format(Locale.US, "%.2f", expense.amount)}",
                fontSize = 16.sp,
                color = MaterialTheme.colorScheme.primary
            )
        }
    }
}

@Composable
fun PhotoViewerDialog(
    photoPath: String,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    val file = File(photoPath)

    // Check if the file exists
    if (!file.exists()) {
        AlertDialog(
            onDismissRequest = onDismiss,
            title = { Text("View Photo") },
            text = { Text("Photo not found at path: $photoPath") },
            confirmButton = {
                Button(onClick = onDismiss) {
                    Text("Close")
                }
            },
            dismissButton = {}
        )
        return
    }

    // Generate a URI for sharing the photo via FileProvider
    val shareUri: Uri? = try {
        FileProvider.getUriForFile(
            context,
            "${context.packageName}.fileprovider",
            file
        )
    } catch (e: Exception) {
        Toast.makeText(context, "Failed to generate share URI: ${e.message}", Toast.LENGTH_LONG).show()
        null
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("View Photo") },
        text = {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Image(
                    painter = rememberAsyncImagePainter(model = file),
                    contentDescription = "Expense Photo",
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(300.dp)
                )
                Spacer(modifier = Modifier.height(16.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly
                ) {
                    // Share Button
                    Button(
                        onClick = {
                            shareUri?.let { uri ->
                                val shareIntent = Intent(Intent.ACTION_SEND).apply {
                                    type = "image/jpeg"
                                    putExtra(Intent.EXTRA_STREAM, uri)
                                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                }
                                context.startActivity(
                                    Intent.createChooser(shareIntent, "Share Photo")
                                )
                            } ?: Toast.makeText(context, "Unable to share photo", Toast.LENGTH_SHORT).show()
                        }
                    ) {
                        Text("Share")
                    }

                    // Download Button
                    Button(
                        onClick = {
                            try {
                                // Copy the photo to the Downloads directory
                                val downloadsDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
                                val destinationFile = File(downloadsDir, "Expense_${System.currentTimeMillis()}.jpg")

                                // Copy the file
                                file.inputStream().use { input ->
                                    FileOutputStream(destinationFile).use { output ->
                                        input.copyTo(output)
                                    }
                                }

                                // Notify the media scanner so the file appears in the gallery/downloads
                                val mediaScanIntent = Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE).apply {
                                    data = Uri.fromFile(destinationFile)
                                }
                                context.sendBroadcast(mediaScanIntent)

                                Toast.makeText(context, "Photo downloaded to Downloads", Toast.LENGTH_SHORT).show()
                            } catch (e: Exception) {
                                Toast.makeText(context, "Failed to download photo: ${e.message}", Toast.LENGTH_LONG).show()
                            }
                        }
                    ) {
                        Text("Download")
                    }
                }
            }
        },
        confirmButton = {
            Button(onClick = onDismiss) {
                Text("Close")
            }
        },
        dismissButton = {}
    )
}

@Composable
fun AddExpenseDialog(
    categories: List<Category>,
    onDismiss: () -> Unit,
    onAddExpense: (Double, String, String, Long, String?) -> Unit,
    requestPhotoPermission: ((() -> Unit) -> Unit),
    requestCameraPermission: ((() -> Unit) -> Unit)
) {
    val context = LocalContext.current
    var amount by rememberSaveable { mutableStateOf("") }
    var description by rememberSaveable { mutableStateOf("") }
    var selectedCategory by rememberSaveable { mutableStateOf(categories.firstOrNull()?.name ?: "") }
    var selectedDate by rememberSaveable { mutableLongStateOf(System.currentTimeMillis()) }
    var dateString by rememberSaveable { mutableStateOf(SimpleDateFormat("dd/MM/yyyy", Locale.US).format(Date(selectedDate))) }
    var photoUri by rememberSaveable { mutableStateOf<Uri?>(null) }
    var photoPath by rememberSaveable { mutableStateOf<String?>(null) }
    var isProcessing by rememberSaveable { mutableStateOf(false) }
    var expanded by rememberSaveable { mutableStateOf(false) }
    var showPhotoOptions by rememberSaveable { mutableStateOf(false) }

    // Create a permanent file for storing the photo
    val photoFile = File(
        context.getExternalFilesDir(Environment.DIRECTORY_PICTURES),
        "IMG_${System.currentTimeMillis()}.jpg"
    )
    val tempPhotoUri = FileProvider.getUriForFile(
        context,
        "${context.packageName}.fileprovider",
        photoFile
    )

    // Photo picker launcher (gallery)
    val pickPhotoLauncher = androidx.activity.compose.rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent(),
        onResult = { uri: Uri? ->
            uri?.let { selectedUri ->
                photoUri = selectedUri
                isProcessing = true
                try {
                    // Copy the selected photo to a permanent file
                    context.contentResolver.openInputStream(selectedUri)?.use { input ->
                        FileOutputStream(photoFile).use { output ->
                            input.copyTo(output)
                        }
                    }
                    photoPath = photoFile.absolutePath
                    Toast.makeText(context, "Photo saved successfully", Toast.LENGTH_SHORT).show()
                } catch (e: Exception) {
                    Toast.makeText(context, "Failed to save photo: ${e.message}", Toast.LENGTH_LONG).show()
                } finally {
                    isProcessing = false
                }
            }
        }
    )

    // Camera capture launcher
    val takePictureLauncher = androidx.activity.compose.rememberLauncherForActivityResult(
        contract = ActivityResultContracts.TakePicture(),
        onResult = { success: Boolean ->
            if (success) {
                photoUri = tempPhotoUri
                isProcessing = true
                try {
                    photoPath = photoFile.absolutePath
                    Toast.makeText(context, "Photo saved successfully", Toast.LENGTH_SHORT).show()
                } catch (e: Exception) {
                    Toast.makeText(context, "Failed to save photo: ${e.message}", Toast.LENGTH_LONG).show()
                } finally {
                    isProcessing = false
                }
            } else {
                Toast.makeText(context, "Failed to capture photo", Toast.LENGTH_SHORT).show()
            }
        }
    )

    // Date picker dialog
    val calendar = Calendar.getInstance()
    val datePickerDialog = DatePickerDialog(
        context,
        { _, year, month, dayOfMonth ->
            calendar.set(year, month, dayOfMonth)
            selectedDate = calendar.timeInMillis
            dateString = SimpleDateFormat("dd/MM/yyyy", Locale.US).format(Date(selectedDate))
        },
        calendar.get(Calendar.YEAR),
        calendar.get(Calendar.MONTH),
        calendar.get(Calendar.DAY_OF_MONTH)
    )

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Add Expense") },
        text = {
            Column {
                OutlinedTextField(
                    value = amount,
                    onValueChange = { amount = it },
                    label = { Text("Amount (R)") },
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(modifier = Modifier.height(8.dp))
                OutlinedTextField(
                    value = description,
                    onValueChange = { description = it },
                    label = { Text("Description") },
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(modifier = Modifier.height(8.dp))
                OutlinedTextField(
                    value = dateString,
                    onValueChange = { /* Read-only field */ },
                    label = { Text("Date") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { datePickerDialog.show() },
                    enabled = false
                )
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = if (photoUri != null) "Photo selected" else "No photo selected",
                        fontSize = 14.sp
                    )
                    Box {
                        Button(
                            onClick = { showPhotoOptions = true },
                            enabled = !isProcessing
                        ) {
                            Text(if (isProcessing) "Processing..." else "Select Photo")
                        }
                        DropdownMenu(
                            expanded = showPhotoOptions,
                            onDismissRequest = { showPhotoOptions = false }
                        ) {
                            DropdownMenuItem(
                                text = { Text("Take Photo") },
                                onClick = {
                                    showPhotoOptions = false
                                    requestCameraPermission {
                                        takePictureLauncher.launch(tempPhotoUri)
                                    }
                                }
                            )
                            DropdownMenuItem(
                                text = { Text("Choose from Gallery") },
                                onClick = {
                                    showPhotoOptions = false
                                    requestPhotoPermission {
                                        pickPhotoLauncher.launch("image/*")
                                    }
                                }
                            )
                        }
                    }
                }
                Spacer(modifier = Modifier.height(8.dp))
                if (categories.isNotEmpty()) {
                    Box {
                        OutlinedTextField(
                            value = selectedCategory,
                            onValueChange = {},
                            label = { Text("Category") },
                            modifier = Modifier.fillMaxWidth(),
                            readOnly = true,
                            trailingIcon = {
                                IconButton(onClick = { expanded = true }) {
                                    Icon(
                                        imageVector = Icons.Default.ArrowDropDown,
                                        contentDescription = "Dropdown"
                                    )
                                }
                            }
                        )
                        DropdownMenu(
                            expanded = expanded,
                            onDismissRequest = { expanded = false },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            categories.forEach { category ->
                                DropdownMenuItem(
                                    text = { Text(category.name) },
                                    onClick = {
                                        selectedCategory = category.name
                                        expanded = false
                                    }
                                )
                            }
                        }
                    }
                } else {
                    Text("No categories available. Add a category first.")
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val amountValue = amount.toDoubleOrNull()
                    if (amountValue != null && description.isNotEmpty() && selectedCategory.isNotEmpty()) {
                        onAddExpense(amountValue, description, selectedCategory, selectedDate, photoPath)
                    }
                },
                enabled = amount.toDoubleOrNull() != null && description.isNotEmpty() && selectedCategory.isNotEmpty() && !isProcessing
            ) {
                Text("Add")
            }
        },
        dismissButton = {
            Button(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}

@Composable
fun AddCategoryDialog(
    onDismiss: () -> Unit,
    onAddCategory: (String) -> Unit
) {
    var categoryName by rememberSaveable { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Add Category") },
        text = {
            OutlinedTextField(
                value = categoryName,
                onValueChange = { categoryName = it },
                label = { Text("Category Name") },
                modifier = Modifier.fillMaxWidth()
            )
        },
        confirmButton = {
            Button(
                onClick = {
                    if (categoryName.isNotEmpty()) {
                        onAddCategory(categoryName)
                    }
                },
                enabled = categoryName.isNotEmpty()
            ) {
                Text("Add")
            }
        },
        dismissButton = {
            Button(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}

@Composable
fun SetGoalDialog(
    onDismiss: () -> Unit,
    onSetGoal: (Double) -> Unit
) {
    var goalAmount by rememberSaveable { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Set Monthly Goal") },
        text = {
            OutlinedTextField(
                value = goalAmount,
                onValueChange = { goalAmount = it },
                label = { Text("Goal Amount (R)") },
                modifier = Modifier.fillMaxWidth()
            )
        },
        confirmButton = {
            Button(
                onClick = {
                    val amount = goalAmount.toDoubleOrNull()
                    if (amount != null) {
                        onSetGoal(amount)
                    }
                },
                enabled = goalAmount.toDoubleOrNull() != null
            ) {
                Text("Set")
            }
        },
        dismissButton = {
            Button(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}

class DashboardViewModel(private val dao: AppDao, private val userId: String) : ViewModel() {
    val latestGoal: StateFlow<Goal?> = dao.getLatestGoalAsFlow(userId)
        .map { it.firstOrNull() }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val expenses: StateFlow<List<Expense>> = dao.getExpensesByDateRange(userId, getStartOfMonth(), getEndOfMonth())
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val categories: StateFlow<List<Category>> = dao.getAllCategories(userId)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun addExpense(amount: Double, description: String, category: String, selectedDate: Long, photoPath: String?) {
        val expense = Expense(
            amount = amount,
            date = selectedDate,
            startTime = selectedDate,
            endTime = selectedDate,
            description = description,
            category = category,
            userId = userId,
            photoPath = photoPath
        )
        viewModelScope.launch {
            dao.insertExpense(expense)
        }
    }

    fun addCategory(name: String) {
        val category = Category(name = name, userId = userId)
        viewModelScope.launch {
            dao.insertCategory(category)
        }
    }

    fun setGoal(amount: Double) {
        val goal = Goal(monthlyGoal = amount, userId = userId)
        viewModelScope.launch {
            dao.insertGoal(goal)
        }
    }

    private fun getStartOfMonth(): Long {
        val calendar = Calendar.getInstance()
        calendar.set(Calendar.DAY_OF_MONTH, 1)
        calendar.set(Calendar.HOUR_OF_DAY, 0)
        calendar.set(Calendar.MINUTE, 0)
        calendar.set(Calendar.SECOND, 0)
        calendar.set(Calendar.MILLISECOND, 0)
        return calendar.timeInMillis
    }

    private fun getEndOfMonth(): Long {
        val calendar = Calendar.getInstance()
        calendar.set(Calendar.DAY_OF_MONTH, calendar.getActualMaximum(Calendar.DAY_OF_MONTH))
        calendar.set(Calendar.HOUR_OF_DAY, 23)
        calendar.set(Calendar.MINUTE, 59)
        calendar.set(Calendar.SECOND, 59)
        calendar.set(Calendar.MILLISECOND, 999)
        return calendar.timeInMillis
    }
}

class DashboardViewModelFactory(private val dao: AppDao, private val userId: String) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(DashboardViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return DashboardViewModel(dao, userId) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}