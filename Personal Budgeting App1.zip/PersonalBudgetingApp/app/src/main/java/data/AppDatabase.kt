package com.example.personalbudgetingapp

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import com.example.personalbudgetingapp.data.AppDao
import com.example.personalbudgetingapp.data.Category
import com.example.personalbudgetingapp.data.Expense
import com.example.personalbudgetingapp.data.Goal

@Database(entities = [Expense::class, Category::class, Goal::class], version = 2, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {

    abstract fun appDao(): AppDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        // Migration from version 1 to 2: Rename photoUrl to photoPath
        private val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(db: SupportSQLiteDatabase) {
                // Create a new table with the updated schema
                db.execSQL("""
                    CREATE TABLE IF NOT EXISTS expenses_new (
                        id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                        amount REAL NOT NULL,
                        date INTEGER NOT NULL,
                        startTime INTEGER NOT NULL,
                        endTime INTEGER NOT NULL,
                        description TEXT NOT NULL,
                        category TEXT NOT NULL,
                        userId TEXT NOT NULL,
                        photoPath TEXT
                    )
                """.trimIndent())

                // Copy data from the old table to the new table, renaming photoUrl to photoPath
                db.execSQL("""
                    INSERT INTO expenses_new (id, amount, date, startTime, endTime, description, category, userId, photoPath)
                    SELECT id, amount, date, startTime, endTime, description, category, userId, photoUrl
                    FROM expenses
                """.trimIndent())

                // Drop the old table
                db.execSQL("DROP TABLE expenses")

                // Rename the new table to the original name
                db.execSQL("ALTER TABLE expenses_new RENAME TO expenses")
            }
        }

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "app_database"
                )
                    .addMigrations(MIGRATION_1_2)
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }
}