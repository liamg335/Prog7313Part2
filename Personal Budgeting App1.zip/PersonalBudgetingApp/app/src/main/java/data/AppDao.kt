package com.example.personalbudgetingapp.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface AppDao {
    // Expense-related queries
    @Insert
    suspend fun insertExpense(expense: Expense): Long

    @Query("SELECT * FROM expenses WHERE date BETWEEN :startDate AND :endDate AND userId = :userId ORDER BY date DESC")
    fun getExpensesByDateRange(userId: String, startDate: Long, endDate: Long): Flow<List<Expense>>

    @Query("SELECT * FROM expenses WHERE category = :category AND date BETWEEN :startDate AND :endDate AND userId = :userId")
    fun getExpensesByCategoryAndDate(userId: String, category: String, startDate: Long, endDate: Long): Flow<List<Expense>>

    // Category-related queries
    @Insert
    suspend fun insertCategory(category: Category): Long

    @Query("SELECT * FROM categories WHERE userId = :userId")
    fun getAllCategories(userId: String): Flow<List<Category>>

    // Goal-related queries
    @Insert
    suspend fun insertGoal(goal: Goal): Long

    @Query("SELECT * FROM goals WHERE userId = :userId ORDER BY id DESC LIMIT 1")
    suspend fun getLatestGoal(userId: String): Goal?

    @Query("SELECT * FROM goals WHERE userId = :userId ORDER BY id DESC LIMIT 1")
    fun getLatestGoalAsFlow(userId: String): Flow<List<Goal>>
}