package com.example.personalbudgetingapp.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "expenses")
data class Expense(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val amount: Double,
    val date: Long,
    val startTime: Long,
    val endTime: Long,
    val description: String,
    val category: String,
    val userId: String,
    val photoPath: String? = null // Renamed from photoUrl to photoPath
)